import librosa
import librosa.display
import matplotlib.pyplot as plt
import numpy as np


# Load audio file
file = 'audio.mp3'
y, sr = librosa.load(file)

# Compute the Short-Time Fourier Transform (STFT)
D = np.abs(librosa.stft(y))

# Convert amplitude spectrogram to decibel (dB) units
D_db = librosa.amplitude_to_db(D, ref=np.max)

# Create a figure and axis
fig, ax = plt.subplots(figsize=(10, 4))

# Display the spectrogram with a standard colormap (e.g., 'viridis')
img = librosa.display.specshow(D_db, sr=sr, x_axis='time', y_axis='log', cmap='viridis', ax=ax)

# Add color bar
cbar = fig.colorbar(img, ax=ax, format='%+2.0f dB')
cbar.set_label('Decibels')

plt.show()
